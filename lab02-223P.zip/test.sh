#!/bin/bash
chmod u+x test.sh
python -m unittest -v test
python -m test
